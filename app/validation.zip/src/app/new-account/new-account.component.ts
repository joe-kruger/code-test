import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms'
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { ApiClientService } from '../services/api-client.service';
import { NewAccountModel } from './new-account.model';

@Component({
  selector: 'app-new-account',
  templateUrl: './new-account.component.html'
})
export class NewAccountComponent implements OnInit {

  /* TODO:
 - Save account using the REST Api
  */
  accountForm : FormGroup;

  constructor(
    private apiService : ApiClientService, 
    private notification : ToastrService, 
    private router : Router, 
    private builder : FormBuilder) {
  }

  ngOnInit(): void {
    this.accountForm = this.builder.group({
      firstName : ['', Validators.required], 
      lastName : ['', Validators.required], 
      balance : [0, Validators.required], 
    });
  }

  onSave(){
    var newAccount = this.accountForm.value as NewAccountModel;
    this.apiService.addAccount(newAccount)
    .subscribe({
      next: () => {
        this.notification.info(`Account created for ${newAccount.firstName} ${newAccount.lastName}`);
        this.router.navigate(['./accounts']);
      }, 
      error : (err) => {
        this.notification.error(err, "Error");
      }
    });
  }
}


