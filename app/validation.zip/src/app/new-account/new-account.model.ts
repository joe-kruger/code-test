export interface NewAccountModel {
    firstName?: string;
    lastName?: string;
    balance?: number;
  }