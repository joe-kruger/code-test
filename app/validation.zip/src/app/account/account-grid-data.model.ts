export interface AccountGridDataModel{
  firstName: string;
  lastName: string;
  typeId: number;
  accountType: string;
  balance: number;
  address: string;
}
