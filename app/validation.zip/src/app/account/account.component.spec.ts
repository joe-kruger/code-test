import { ComponentFixture, TestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { AccountComponent } from './account.component';
import { HttpClientModule } from '@angular/common/http';
import { ApiClientService } from '../services/api-client.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('AccountComponent', () => {
  let component: AccountComponent;
  let fixture: ComponentFixture<AccountComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, HttpClientModule, RouterTestingModule], 
      providers: [ApiClientService],
      declarations: [ AccountComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AccountComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create accounts$ observable', () => {
    expect(component.accounts$).toBeDefined();
  })

  it('should create gridAccounts$ observable', () => {
    expect(component.gridAccounts$).toBeDefined();
  })

});
