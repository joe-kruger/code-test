export interface AccountModel {
  firstName: string;
  lastName: string;
  typeId: number;
  balance: number;
  address: string;
}
