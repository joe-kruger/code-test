import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { BehaviorSubject, combineLatest, EMPTY, Observable } from 'rxjs';
import { catchError, map, shareReplay, startWith, tap } from 'rxjs/operators';
import { ApiClientService } from '../services/api-client.service';
import { AccountGridDataModel } from './account-grid-data.model';

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html'
})
export class AccountComponent {

  constructor(private apiClient : ApiClientService, private router : Router) { 
    
   }

  accountType: FormControl = new FormControl(0); 
  errorMessage : string;

  accounts$ = this.apiClient.getAllAccounts();
  accountTypes$ = this.apiClient.getAllAccountTypes$;

  //combines the latest from accounts$ and selectedType$ observable effectively invoking next 
  //every time the accounts refresh or user selects a new value in dropdown.
  //The pipe function merely filters the list according the selected type.
  selectedAccounts$ = combineLatest([
    this.accounts$, 
    this.accountType.valueChanges.pipe(startWith(0))
  ]).pipe(
    map(([accounts, selectedType]) => accounts.filter(acc => selectedType ? acc.typeId === selectedType : true)),
    catchError(err=> {
      this.errorMessage = err;
      return EMPTY;
    })
  );

  //combines the latest from selectedAccounts$ and accountTypes$ observables to map
  //the results into AccountGridDataModel objects which display the account Type
  gridAccounts$ = combineLatest([
    this.selectedAccounts$, 
    this.accountTypes$
  ]).pipe(
    map( ([accounts, accountTypes])=> 
      accounts.map(acc => ({
          ...acc, 
          accountType : accountTypes.find(t=> t.id == acc.typeId).name
        }) as AccountGridDataModel)
      ) 
  );




  openNewAccount(): void {
     this.router.navigate(['/new-account']);
  }
}
