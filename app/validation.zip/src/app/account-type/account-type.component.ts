import { Component, forwardRef, Input, OnInit, Output } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { EventEmitter } from 'protractor';
import { BehaviorSubject, Subject } from 'rxjs';
import { ApiClientService } from '../services/api-client.service';
import { AccountTypeModel } from './account-type.model';

const CUSTOM_VALUE_ACCESSOR: any = {
  provide : NG_VALUE_ACCESSOR,
  useExisting: forwardRef(() => AccountTypeComponent),
  multi : true, 
  }; 

@Component({
  selector: 'app-account-type',
  providers : [CUSTOM_VALUE_ACCESSOR],
  templateUrl: './account-type.component.html'
})
export class AccountTypeComponent implements OnInit, ControlValueAccessor  {

  /* TODO:
  - Load Accounts Types from the REST Api
  - Observable should be used to notify the account.component about changes in the selected Type
   */
  private selectedType : number;
  private disabled: boolean;
  private onChange: Function; 
  private onTouched: Function; 
  
  accountTypes$ = this.apiClient.getAllAccountTypes$;

  constructor(private apiClient : ApiClientService) {
    this.onChange = (_: any) => {};
    this.onTouched = () => {};
    this.disabled = false; 
  }
  ngOnInit(): void {
    this.onChange(this.selectedType);
  }

  writeValue(value: any): void {
    this.selectedType = value; 
    this.onChange(+value);
  }

  registerOnChange(fn: any): void {
    this.onChange = fn; 
    this.onChange(this.selectedType);
  }
  registerOnTouched(fn: any): void {
    this.onTouched = fn; 
  }
  
  setDisabledState?(isDisabled: boolean): void {
    this.disabled = isDisabled; 
  }

  onSelected(value : string) {
    this.selectedType = +value;
    this.onChange(+value);
    this.onTouched(); 
  }
}
