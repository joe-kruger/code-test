import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, shareReplay, tap } from 'rxjs/operators';
import { types } from 'util';
import { AccountTypeModel } from '../account-type/account-type.model';
import { AccountModel } from '../account/account.model';
import { NewAccountModel } from '../new-account/new-account.model';


@Injectable({
  providedIn: 'root'
})
export class ApiClientService {
  private baseUri: string = "https://localhost:5001";

  constructor(private http: HttpClient) {
    console.log('ApiClientService.Constructor()...');
  }

  getAllAccountTypes$ = this.http
      .get<AccountTypeModel[]>(`${this.baseUri}/accounttype`)
      .pipe(
        shareReplay(1),
        tap(types => console.log(`Retrieved ${types.length} Account types from API.`)),
        catchError(this.extractErrorMessage)
      );
  

  getAllAccounts(): Observable<AccountModel[]> {
    return this.http
      .get<AccountModel[]>(`${this.baseUri}/accounts`)
      .pipe(
        catchError(this.extractErrorMessage)
      );
  }

  addAccount(account: NewAccountModel): Observable<Object> {
    return this.http.post(`${this.baseUri}/accounts`, account)
      .pipe(
        catchError(this.extractErrorMessage)
      );;
  }

  private extractErrorMessage(err: any): Observable<never> {
    let message: string;
    if (err.error instanceof ErrorEvent) {
      message = err.error.message;
    }
    else {
      if (Array.isArray(err.error) && err.error.length > 0) {
        message = err.error[0];
      }
      else {
        message = `${err.status} : ${err.body.error}`;
      }

    }
    console.log(err);
    return throwError(message);
  }

}